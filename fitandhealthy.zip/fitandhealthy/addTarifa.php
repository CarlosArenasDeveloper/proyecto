<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json=file_get_contents('php://input');
$params=json_decode($json);
try {
    $stmt = $conn->prepare("INSERT INTO `tarifas` (`id`,`nombre`, `descripcion`, `precio`) VALUES (NULL,?,?,?)");
    $stmt->bindParam(1,$params->nombre);
    $stmt->bindParam(2,$params->descripcion);
    $stmt->bindParam(3,$params->precio);
    $stmt->execute();
    
} catch (PDOException $exception) {
    echo json_encode($exception);
}