<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$array=[];
try {
    $stmt = $conn->prepare("SELECT * FROM `colores` where codigo not in (select color from actividades) or codigo=:codigo");
    $stmt->bindParam(":codigo",$_GET['codigo']);
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    echo json_encode($filasobtenidas);
} catch (PDOException $exception) {
    echo $exception;
}
?>

