<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$jsondata = [];
$resultado = [];
$id_tarifa = $_GET["id_tarifa"];
try {

    // $stmtPlus = $conn->prepare("select * from sesiones WHERE (end <= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND)) and  (estado='incompleta' or estado='completa'))");
    // $stmtPlus->execute();
    // if ($stmtPlus->rowCount() > 0) {
    //     $filasObtenidasPlus = $stmtPlus->fetchAll();
    //     foreach ($filasObtenidasPlus as $filaPlus) {
    //         $stm3Plus = $conn->prepare("UPDATE reservas set estado='realizada' WHERE id_sesion=:id_sesion");
    //         $stm3Plus->bindParam(":id_sesion", $filaPlus->id);
    //         $stm3Plus->execute();
    //     }
    // }

    $stmtPlus = $conn->prepare("select * from sesiones WHERE (end <= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND)) and  (estado='incompleta' or estado='completa'))");
    $stmtPlus->execute();
    if ($stmtPlus->rowCount() > 0) {
        $filasObtenidasPlus = $stmtPlus->fetchAll();
        foreach ($filasObtenidasPlus as $filaPlus) {
            $stm2Plus = $conn->prepare("UPDATE sesiones set estado='finalizada' WHERE id=:id");
            $stm2Plus->bindParam(":id", $filaPlus->id);
            $stm2Plus->execute();
        }
    }

    $stmtPlus2 = $conn->prepare("select * from sesiones s,reservas r WHERE s.estado='finalizada' and r.estado='pendiente' and r.id_sesion=s.id");
    $stmtPlus2->execute();
    if ($stmtPlus2->rowCount() > 0) {
        $filasObtenidasPlus2 = $stmtPlus2->fetchAll();
        foreach ($filasObtenidasPlus2 as $filaPlus2) {
            $stm2Plus2 = $conn->prepare("UPDATE reservas set estado='realizada' WHERE id_sesion=:id_sesion");
            $stm2Plus2->bindParam(":id_sesion", $filaPlus2->id_sesion);
            $stm2Plus2->execute();
        }
    }



    if ($id_tarifa == 1) {
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1");
    } else if ($id_tarifa == 2) {
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2");
    } else if ($id_tarifa == 3) {
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2 || id_tarifa=3");
    } else {
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=:id_tarifa");
        $stmt->bindParam(":id_tarifa", $id_tarifa);
    }

    $stmt->execute();
    $filasobtenidaspremium = $stmt->fetchAll();

    $s = $conn->prepare("SELECT * FROM sesiones where title=:title and sala is not null and start >= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND))");
    $stmt2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");
    $stmt3 = $conn->prepare("SELECT aforo FROM salas where id=:sala");

    foreach ($filasobtenidaspremium as $filapremium) {
        $s->bindParam(":title", $filapremium->id);
        $s->execute();
        if ($s->rowCount() > 0) {
            $filasobtenidas = $s->fetchAll();
            foreach ($filasobtenidas as $fila) {
                $stmt2->bindParam(":id", $fila->title);
                $stmt2->execute();
                $filaObt = $stmt2->fetch();
                $actividad = $filaObt->nombre;
                $fila->title = $actividad;


                $stmt3->bindParam(":sala", $fila->sala);
                $stmt3->execute();
                $filaObt2 = $stmt3->fetch();
                $aforo = $filaObt2->aforo;
                $fila->aforo = $aforo;


                if ($fila->aforo <= $fila->num_clientes && $fila->estado == 'incompleta') {
                    $stm4 = $conn->prepare("UPDATE sesiones set estado='completa' WHERE id=:id");
                    $stm4->bindParam(":id", $fila->id);
                    $stm4->execute();
                }
                $jsondata[] = $fila;
            }
        }
    }
    echo json_encode($jsondata);
} catch (PDOException $exception) {
    echo json_encode($exception);
}


// <?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();
// $jsondata = [];
// $id_tarifa = $_GET["id_tarifa"];
// try {
//     if ($id_tarifa == 1) {
//         $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1");
//     } else if ($id_tarifa == 2) {
//         $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2");
//     } else if ($id_tarifa == 3) {
//         $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2 || id_tarifa=3");
//     } else {
//         $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=:id_tarifa");
//         $stmt->bindParam(":id_tarifa", $id_tarifa);
//     }

//     $stmt->execute();
//     $filasobtenidaspremium = $stmt->fetchAll();
    
//     $s = $conn->prepare("SELECT * FROM sesiones where title=:title and sala is not null and start >= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND))");
    
//     foreach ($filasobtenidaspremium as $filapremium) {
//         $s->bindParam(":title", $filapremium->id);
//         $s->execute();
//         if ($s->rowCount() > 0) {
//             $filasobt=$s->fetchAll();
//             echo json_encode($filasobt);
//         }
//     }
// } catch (PDOException $exception) {
//     echo json_encode($exception);
// }
