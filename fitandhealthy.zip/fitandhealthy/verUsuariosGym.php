<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();


$jsondata;

try {
    $stmt = $conn->prepare("SELECT COUNT(*) as usuarios FROM usuarios where id_centro=:id");
    $stmt->bindParam(":id", $_GET["id"]);
    $stmt->execute();
    $filas=$stmt->fetch();
    $numeroUsuarios=$filas->usuarios;
    echo $numeroUsuarios;
} catch (PDOException $exception) {
    json_encode($exception);
}
