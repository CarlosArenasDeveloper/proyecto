<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();


$jsondata;

try {
    $stmt = $conn->prepare("DELETE FROM usuarios where email=:email");
    $stmt->bindParam(":email", $_GET["email"]);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
