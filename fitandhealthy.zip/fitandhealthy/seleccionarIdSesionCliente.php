<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
$arrayIDsesiones = [];
try {

    $stmt = $conn->prepare("SELECT * FROM reservas where email_cliente=:email_cliente");
    $stmt->bindParam(":email_cliente", $_GET['email_cliente']);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $filasObtenidas = $stmt->fetchAll();
        foreach ($filasObtenidas as $fila) {
            array_push($arrayIDsesiones, $fila->id_sesion);
        }
    }
    echo json_encode($arrayIDsesiones);

} catch (PDOException $exception) {
    echo json_encode($exception);
}

