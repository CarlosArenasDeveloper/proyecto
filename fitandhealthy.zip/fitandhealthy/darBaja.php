<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE usuarios set fecha_baja=?,num_reservas=?,estado=?,fecha_alta=NULL
    WHERE email=?");
    $stmt->bindParam(1, $params->fecha_baja);
    $stmt->bindParam(2, $params->num_reservas);
    $stmt->bindParam(3, $params->estado);
    $stmt->bindParam(4, $params->email);
    $stmt->execute();
    

    $stmtB=$conn->prepare("SELECT * FROM reservas where email_cliente=:email_cliente");
    $stmtB->bindParam(":email_cliente",$params->email);
    $stmtB->execute();
    $filasB=$stmtB->fetchAll();
    foreach($filasB as $filaB){
        $sesion=$filaB->id_sesion;
        $stmtA = $conn->prepare("DELETE FROM reservas where id_sesion=:id_sesion and email_cliente=:email_cliente");
        $stmtA->bindParam(":id_sesion", $sesion);
        $stmtA->bindParam(":email_cliente", $params->email);
        $stmtA->execute();
    
        $stm2 = $conn->prepare("UPDATE sesiones set num_clientes=num_clientes-1 WHERE id=:id");
        $stm2->bindParam(":id", $sesion);
        $stm2->execute();
    
        $stm3 = $conn->prepare("UPDATE usuarios set num_reservas=num_reservas-1 WHERE email=:email");
        $stm3->bindParam(":email", $sesion);
        $stm3->execute();
    
        $stm4 = $conn->prepare("SELECT * from sesiones where id=:id");
        $stm4->bindParam(":id", $sesion);
        $stm4->execute();
        if ($stm4->rowCount() > 0) {
            $filaObtenida = $stm4->fetch();
            if ($filaObtenida->estado == 'completa') {
                $stm5 = $conn->prepare("UPDATE sesiones set estado='incompleta' WHERE id=:id");
                $stm5->bindParam(":id", $sesion);
                $stm5->execute();
            }
        }
    }



    echo json_encode("correcto");
} catch (PDOException $exception) {
    json_encode($exception);
}
