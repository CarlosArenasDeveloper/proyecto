<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
require_once 'conexion.php';
$conn = openConection();
$json = file_get_contents('php://input');
$params = json_decode($json);
$color;
try {
    $stmt = $conn->prepare("SELECT * FROM sesiones WHERE (((:inicio BETWEEN start AND end) OR (:fin BETWEEN start AND end) OR (:inicio <=start and :fin >=end)) and title=:actividad) OR 
  (((:inicio BETWEEN start AND end) OR (:fin BETWEEN start AND end) OR (:inicio <=start and :fin >=end))  and sala=:sala)");
    $stmt->bindParam(":inicio", $params->start);
    $stmt->bindParam(":fin", $params->end);
    $stmt->bindParam(":sala", $params->sala);
    $stmt->bindParam(":actividad", $params->title);
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        echo json_encode("error");
    } else {
        try {
            $stmt3 = $conn->prepare("SELECT color FROM actividades where id=:id");
            $stmt3->bindParam(":id", $params->title);
            $stmt3->execute();
            $filasobtenidas2 = $stmt3->fetch();
            if ($stmt3->rowCount() > 0) {
                $color=$filasobtenidas2->color;
            } else {
                $color="";
            }

            $stm2 = $conn->prepare("INSERT INTO `sesiones` (`title`,`start`, `end`,`sala`,`color`) VALUES (:title,:start,:end,:sala,:color)");
            $stm2->bindParam(":title", $params->title);
            $stm2->bindParam(":start", $params->start);
            $stm2->bindParam(":end", $params->end);
            $stm2->bindParam(":sala", $params->sala);
            $stm2->bindParam(":color", $color);
            $stm2->execute();
        } catch (PDOException $exception) {
            echo json_encode($exception);
        }
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
