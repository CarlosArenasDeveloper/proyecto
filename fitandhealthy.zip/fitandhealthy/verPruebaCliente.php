<?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();
// $jsondata = [];
// try {
//     $stmt = $conn->prepare("SELECT * FROM sesiones where title is not null and sala is not null and start >= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND))");
//     $stmt2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");
//     $stmt3 = $conn->prepare("SELECT aforo FROM salas where id=:sala");

//     $stmt->execute();
//     if ($stmt->rowCount() > 0) {
//         $filasobtenidas = $stmt->fetchAll();
//         foreach ($filasobtenidas as $fila) {
//             $stmt2->bindParam(":id", $fila->title);
//             $stmt2->execute();
//             $filaObt = $stmt2->fetch();
//             $actividad = $filaObt->nombre;
//             $fila->title = $actividad;


//             $stmt3->bindParam(":sala", $fila->sala);
//             $stmt3->execute();
//             $filaObt2 = $stmt3->fetch();
//             $aforo = $filaObt2->aforo;
//             $fila->aforo = $aforo;


//             if ($fila->aforo <= $fila->num_clientes && $fila->estado == 'incompleta') {
//                 $stm4 = $conn->prepare("UPDATE sesiones set estado='completa' WHERE id=:id");
//                 $stm4->bindParam(":id", $fila->id);
//                 $stm4->execute();
//             }

//             $jsondata[] = $fila;
//         }
//     }
//     echo json_encode($jsondata);
// } catch (PDOException $exception) {
//     echo json_encode($exception);
// }
