<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$id_tarifa=$_GET["id_tarifa"];
try {
    if($id_tarifa==1){
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1");
    }else if($id_tarifa==2){
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2");
    }else if($id_tarifa==3){
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=1 || id_tarifa=2 || id_tarifa=3");
    }else{
        $stmt = $conn->prepare("SELECT * FROM actividades where id_tarifa=:id_tarifa");
        $stmt->bindParam(":id_tarifa",$id_tarifa);
    }
    
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    echo json_encode($filasobtenidas);
} catch (PDOException $exception) {
    echo json_encode($exception);
}
