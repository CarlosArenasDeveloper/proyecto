<?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();
// $datos = [];
// try {
//     $stmt = $conn->prepare("SELECT * FROM reservas where email_cliente=:email_cliente");
//     $stmt2 = $conn->prepare("SELECT * FROM sesiones where id=:id");
//     $stmt->bindParam(":email_cliente", $_GET['email_cliente']);
//     $stmt->execute();
//     if ($stmt->rowCount() > 0) {
//         $filaObtenidas = $stmt->fetchAll();
//         foreach ($filaObtenidas as $fila) {
//             $stmt2->bindParam(":id", $fila->id_sesion);
//             $stmt2->execute();
//             $filaObtenida = $stmt2->fetch();
//             array_push($datos, $filaObtenida);
//         }

//         echo json_encode($datos);
//     }


// } catch (PDOException $exception) {
//     echo json_encode($exception);
// }

header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$datos = [];
$jsondata = [];

try {
    $stmt = $conn->prepare("SELECT * FROM reservas where email_cliente=:email_cliente");
    $stmt1 = $conn->prepare("SELECT * FROM sesiones where id=:id");
    $stmt2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");
    $stmt3 = $conn->prepare("SELECT aforo FROM salas where id=:sala");
    $stmt->bindParam(":email_cliente", $_GET['email_cliente']);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $filaObtenidas = $stmt->fetchAll();
        foreach ($filaObtenidas as $fila) {
            $stmt1->bindParam(":id", $fila->id_sesion);
            $stmt1->execute();
            $filaObtenida = $stmt1->fetch();
            array_push($datos, $filaObtenida);
        }

        foreach($datos as $fila){
            if ($fila->title != null) {
                $stmt2->bindParam(":id", $fila->title);
                $stmt2->execute();
                $filaObt = $stmt2->fetch();
                $actividad = $filaObt->nombre;
                $fila->title = $actividad;
            } else {
                $fila->title = "Actividad sin asignar";
            }
            if ($fila->sala == null) {
                $fila->sala = "sin asignar";
            }

            if ($fila->sala != null) {
                $stmt3->bindParam(":sala", $fila->sala);
                $stmt3->execute();
                $filaObt2 = $stmt3->fetch();
                $aforo = $filaObt2->aforo;
                $fila->aforo = $aforo;
            }

            if ($fila->aforo <= $fila->num_clientes && $fila->estado == 'incompleta') {
                $stm4 = $conn->prepare("UPDATE sesiones set estado='completa' WHERE id=:id");
                $stm4->bindParam(":id", $fila->id);
                $stm4->execute();
            }



            $jsondata[] = $fila;
        }
        echo json_encode($jsondata);

    }

  
} catch (PDOException $exception) {
    echo json_encode($exception);
}

