<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$mismoNombre = false;

$json = file_get_contents('php://input');
try {
    $stmt2 = $conn->prepare("SELECT * FROM categorias");
    $stmt2->execute();
    $filasObtenidas = $stmt2->fetchAll();
    $stmt = $conn->prepare("INSERT INTO `categorias` (`nombre`) VALUES (?)");

    if ($stmt2->rowCount() > 0) {
        foreach ($filasObtenidas as $fila) {
            if ($fila->nombre == $_GET['nombre']) {
                $mismoNombre = true;
            }
        }
    }

    if ($mismoNombre==false) {
        $stmt->bindParam(1, $_GET['nombre']);
        $stmt->execute();
    } else {
        echo json_encode("ya existe");
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
