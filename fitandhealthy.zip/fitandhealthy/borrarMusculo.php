<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();


$jsondata;

try {
    $stmt = $conn->prepare("DELETE FROM musculosprincipales where nombre=:nombre");
    $stmt->bindParam(":nombre", $_GET["nombre"]);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
