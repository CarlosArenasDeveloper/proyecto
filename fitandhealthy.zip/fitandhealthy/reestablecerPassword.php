<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE usuarios set password=?
    WHERE email=?");
    $stmt->bindParam(1, $params->password);
    $stmt->bindParam(2,$params->email);
    $stmt->execute();
    echo json_encode("correcto");
} catch (PDOException $exception) {
    json_encode($exception);
}
