<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("SELECT email,nombre,apellido1,apellido2 FROM usuarios where role!=2 order by apellido1");
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    $jsondata = $filasobtenidas;
} catch (PDOException $exception) {
    echo json_encode ($exception);
}
echo json_encode($jsondata);