<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$array=[];
try {
    $stmt = $conn->prepare("SELECT * FROM tarifas");
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    $array=$filasobtenidas;
    echo json_encode($array);
} catch (PDOException $exception) {
    echo $exception;
}
?>

