<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$jsondata = [];

try {
    $stmtPlus = $conn->prepare("select * from sesiones WHERE (end <= (DATE_SUB(sysdate(), INTERVAL '0 2:0:0' DAY_SECOND)) and  (estado='incompleta' or estado='completa'))");
    $stmtPlus->execute();
    if ($stmtPlus->rowCount() > 0) {
        $filasObtenidasPlus = $stmtPlus->fetchAll();
        foreach ($filasObtenidasPlus as $filaPlus) {
            $stm2Plus = $conn->prepare("UPDATE sesiones set estado='finalizada' WHERE id=:id");
            $stm2Plus->bindParam(":id", $filaPlus->id);
            $stm2Plus->execute();
        }
    }
    
    $stmt = $conn->prepare("SELECT * FROM actividades where email_monitor=:email_monitor");
    $stmt1 = $conn->prepare("SELECT * FROM sesiones where title=:title");
    $stmt2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");
    $stmt3 = $conn->prepare("SELECT aforo FROM salas where id=:sala");

    
    $stmt->bindParam(":email_monitor", $_GET['email_monitor']);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $filaObtenida = $stmt->fetch();
        $stmt1->bindParam(":title",$filaObtenida->id);
        $stmt1->execute();
        if($stmt1->rowCount()>0){
            $filasobtenidas=$stmt1->fetchAll();
            foreach ($filasobtenidas as $fila) {
                if ($fila->title != null) {
                    $stmt2->bindParam(":id", $fila->title);
                    $stmt2->execute();
                    $filaObt = $stmt2->fetch();
                    $actividad = $filaObt->nombre;
                    $fila->title = $actividad;
                } else {
                    $fila->title = "Actividad sin asignar";
                }
                if ($fila->sala == null) {
                    $fila->sala = "sin asignar";
                }
    
                if ($fila->sala != null) {
                    $stmt3->bindParam(":sala", $fila->sala);
                    $stmt3->execute();
                    $filaObt2 = $stmt3->fetch();
                    $aforo = $filaObt2->aforo;
                    $fila->aforo = $aforo;
                }
    
                if ($fila->aforo <= $fila->num_clientes && $fila->estado == 'incompleta') {
                    $stm4 = $conn->prepare("UPDATE sesiones set estado='completa' WHERE id=:id");
                    $stm4->bindParam(":id", $fila->id);
                    $stm4->execute();
                }
    
    
    
                $jsondata[] = $fila;
            }
            echo json_encode($jsondata);
        }
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}




// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();
// try {
    
//     $stmt = $conn->prepare("SELECT * FROM actividades where email_monitor=:email_monitor");
//     $stmt1 = $conn->prepare("SELECT * FROM sesiones where title=:title");
    
//     $stmt->bindParam(":email_monitor", $_GET['email_monitor']);
//     $stmt->execute();
//     if ($stmt->rowCount() > 0) {
//         $filaObtenida = $stmt->fetch();
//         $stmt1->bindParam(":title",$filaObtenida->id);
//         $stmt1->execute();
//         if($stmt1->rowCount()>0){
//             $filasobtenidas=$stmt1->fetchAll();
//             echo json_encode($filasobtenidas);
//         }
//     }
// } catch (PDOException $exception) {
//     echo json_encode($exception);
// }
