<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE usuarios set dni=?
    ,password=?,nombre=?,apellido1=?,
    apellido2=?,fecha_nac=?,sexo=?,telefono=?,cuenta_bancaria=?,ciudad=?,direccion=?
    ,cod_postal=?,id_tarifa=?,id_centro=?,fecha_alta=?,fecha_baja=?,num_reservas=?,role=?,verificado=?,estado=?,imagen=?
    WHERE email=?");
    $stmt->bindParam(1, $params->dni);
    $stmt->bindParam(2, $params->password);
    $stmt->bindParam(3, $params->nombre);
    $stmt->bindParam(4, $params->apellido1);
    $stmt->bindParam(5, $params->apellido2);
    $stmt->bindParam(6, $params->fecha_nac);
    $stmt->bindParam(7, $params->sexo);
    $stmt->bindParam(8, $params->telefono);
    $stmt->bindParam(9, $params->cuenta_bancaria);
    $stmt->bindParam(10, $params->ciudad);
    $stmt->bindParam(11, $params->direccion);
    $stmt->bindParam(12, $params->cod_postal);
    $stmt->bindParam(13, $params->id_tarifa);
    $stmt->bindParam(14, $params->id_centro);
    $stmt->bindParam(15, $params->fecha_alta);
    $stmt->bindParam(16, $params->fecha_baja);
    $stmt->bindParam(17, $params->num_reservas);
    $stmt->bindParam(18, $params->role);
    $stmt->bindParam(19, $params->verificado);
    $stmt->bindParam(20,$params->estado);
    $stmt->bindParam(21,$params->imagen);
    $stmt->bindParam(22,$params->email);



    $stmt->execute();
    echo json_encode("correcto");
} catch (PDOException $exception) {
    json_encode($exception);
}
