<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("DELETE FROM reservas where id_sesion=:id_sesion and email_cliente=:email_cliente");
    $stmt->bindParam(":id_sesion", $params->id_sesion);
    $stmt->bindParam(":email_cliente", $params->email_cliente);
    $stmt->execute();

    $stm2 = $conn->prepare("UPDATE sesiones set num_clientes=num_clientes-1 WHERE id=:id");
    $stm2->bindParam(":id", $params->id_sesion);
    $stm2->execute();

    $stm3 = $conn->prepare("UPDATE usuarios set num_reservas=num_reservas-1 WHERE email=:email");
    $stm3->bindParam(":email", $params->email_cliente);
    $stm3->execute();

    $stm4 = $conn->prepare("SELECT * from sesiones where id=:id");
    $stm4->bindParam(":id", $params->id_sesion);
    $stm4->execute();
    if ($stm4->rowCount() > 0) {
        $filaObtenida = $stm4->fetch();
        if ($filaObtenida->estado == 'completa') {
            $stm5 = $conn->prepare("UPDATE sesiones set estado='incompleta' WHERE id=:id");
            $stm5->bindParam(":id", $params->id_sesion);
            $stm5->execute();
        }
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
