<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json=file_get_contents('php://input');
$params=json_decode($json);
try {
    $stmt = $conn->prepare("INSERT INTO `centros` (`id`,`nombre`, `direccion`, `telefono`,`latitud`,`longitud`,`ubicacion`) VALUES (NULL,?,?,?,?,?,?)");
    $stmt->bindParam(1,$params->nombre);
    $stmt->bindParam(2,$params->direccion);
    $stmt->bindParam(3,$params->telefono);
    $stmt->bindParam(4,$params->latitud);
    $stmt->bindParam(5,$params->longitud);
    $stmt->bindParam(6,$params->ubicacion);
    $stmt->execute();
    
} catch (PDOException $exception) {
    echo json_encode($exception);
}

