<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';

$conn = openConection();
try {
    $stmt = $conn->prepare("SELECT * FROM ejercicios where nombre_musculo=:nombre_musculo order by nombre");
    $stmt->bindParam(":nombre_musculo",$_GET["nombre_musculo"]);
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        echo json_encode($filasobtenidas);
    } else {
        echo json_encode("error");
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
