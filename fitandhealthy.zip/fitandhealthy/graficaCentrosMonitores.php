<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("SELECT c.nombre, COUNT(*) as centros FROM usuarios u, centros c where u.role=3 and u.id_centro=c.id GROUP BY id_centro");
    $stmt->execute();
    $filasObtenidas = $stmt->fetchAll();
    echo json_encode($filasObtenidas);
} catch (PDOException $exception) {
    echo json_encode ($exception);
}
