<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE musculosprincipales set descripcion=?,imagen=?
    WHERE nombre=?");
    $stmt->bindParam(1, $params->descripcion);
    $stmt->bindParam(2, $params->imagen);
    $stmt->bindParam(3, $params->nombre);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
