<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();



try {
    $stmt = $conn->prepare("SELECT * FROM categorias");
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();

    $jsondata = $filasobtenidas;
} catch (PDOException $exception) {
    echo $exception;
}
echo json_encode($jsondata);
