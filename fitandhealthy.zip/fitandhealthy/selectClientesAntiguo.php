<?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();


// $jsondata=[];

//     try {
//         $stmt = $conn->prepare("SELECT * FROM usuarios where role=2 order by apellido1");
//         $stmt2 = $conn->prepare("SELECT nombre  FROM centros where id=:id");
//         $stmt3 = $conn->prepare("SELECT nombre  FROM tarifas where id=:id");

//         $stmt->execute();
//         $filasobtenidas = $stmt->fetchAll();
//         if ($stmt->rowCount() > 0) {
//             $jsondata=$filasobtenidas;
//             // foreach($filasobtenidas as $fila){
//             //     $stmt2->bindParam(":id",$fila->id_centro);
//             //     $stmt3->bindParam(":id",$fila->id_tarifa);
//             //     $stmt2->execute();
//             //     $stmt3->execute();
//             //     $filaObt=$stmt2->fetch();
//             //     $filaObt2=$stmt3->fetch();
//             //     $centro=$filaObt->nombre;
//             //     $tarifa=$filaObt2->nombre;
//             //     $fila->id_centro=$centro;
//             //     $fila->id_tarifa=$tarifa;
//             //     $jsondata[]= $fila;
//             // }
//         } else {
//             $jsondata[]="Error";
//         }
//     } catch (PDOException $exception) {
//         echo $exception;
//     }
// echo json_encode($jsondata);
