<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
try {
    $stmt = $conn->prepare("SELECT * FROM actividades where id=:id order by nombre desc");
    $stmt->bindParam(":id",$_GET["id"]);
    $stmt2 = $conn->prepare("SELECT nombre  FROM tarifas where id=:id");
    $stmt3=$conn->prepare("SELECT * from usuarios where email=:email ");

    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        foreach ($filasobtenidas as $fila) {
            if ($fila->id_tarifa != null) {
                $stmt2->bindParam(":id", $fila->id_tarifa);
                $stmt2->execute();
                $filaObt = $stmt2->fetch();
                $tarifa = $filaObt->nombre;
                $fila->id_tarifa = $tarifa;
            } else {
                $fila->id_tarifa = "sin asignar";
            }

            if($fila->email_monitor!=null){
                $stmt3->bindParam(":email", $fila->email_monitor);
                $stmt3->execute();
                $filaObtenida = $stmt3->fetch();
                $nombreCompleto = $filaObtenida->nombre . " ". $filaObtenida->apellido1 ." ". $filaObtenida->apellido2;
                $fila->email_monitor = $nombreCompleto;
            }else {
                $fila->email_monitor = "monitor no asignado";
            }

        
            $jsondata = $fila;
        }
    } else {
        $jsondata = "error";
    }
    echo json_encode($jsondata);
} catch (PDOException $exception) {
    echo json_encode($exception);
}
