<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("INSERT INTO `reservas` (`id`,`email_cliente`, `id_sesion`) VALUES (NULL,?,?)");
    $stmt->bindParam(1, $params->email_cliente);
    $stmt->bindParam(2, $params->id_sesion);
    $stmt->execute();

    $stm2 = $conn->prepare("UPDATE sesiones set num_clientes=num_clientes+1 WHERE id=:id");
    $stm2->bindParam(":id", $params->id_sesion);
    $stm2->execute();

    $stm3 = $conn->prepare("UPDATE usuarios set num_reservas=num_reservas+1 WHERE email=:email");
    $stm3->bindParam(":email", $params->email_cliente);
    $stm3->execute();

    $consulta = $conn->prepare("SELECT DATE_ADD(start, INTERVAL '0 2:0:0' DAY_SECOND) AS start,title,sala,id,num_clientes,estado,color,end from sesiones where id=:id");
    $consulta2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");
    $consulta3 = $conn->prepare("SELECT aforo FROM salas where id=:sala");
    $consulta->bindParam(":id", $params->id_sesion);
    $consulta->execute();
    if ($consulta->rowCount() > 0) {
        $sesionReservada = $consulta->fetch();
        if ($sesionReservada->title != null) {
            $consulta2->bindParam(":id", $sesionReservada->title);
            $consulta2->execute();
            $filaObt = $consulta2->fetch();
            $actividad = $filaObt->nombre;
            $sesionReservada->title = $actividad;
        } else {
            $sesionReservada->title = "Actividad sin asignar";
        }

        $html = "<html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <title>Reserva realizada</title>
            <link rel='stylesheet' href='estilos.css'>
        </head>
        <body>";
        $html .= "<h1>Reserva realizada</h1>";
        $html .= "<table>";
        $html .= "</table></body></html>";

        // require_once __DIR__ . '/vendor/autoload.php';
        require 'vendor/autoload.php';
        $mail = new PHPMailer(true);
        try {
            //  $mail->SMTPDebug=0;
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'fitandhealthycm@gmail.com';                     // SMTP username
            $mail->Password   = 'fitandhealthy';                               // SMTP password
            $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            $mail->SMTPSecure = 'tls';        // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged

            //Recipients
            $mail->setFrom('fitandhealthycm@gmail.com', 'FIT & HEALTHY');
           // $mail->addAddress($params->email_cliente);     // Add a recipient 
           $mail->addAddress($params->email_cliente);     // Add a recipient 

            // Content
            $mail->isHTML(true);
            $mail->Subject = "Reserva realizada";
            $fecha = $sesionReservada->start;
            $fechaComoEntero = strtotime($fecha);
            $anio = date("Y", $fechaComoEntero);
            $mes = date("m", $fechaComoEntero);
            $dia = date("d", $fechaComoEntero);
            $hora = date("H", $fechaComoEntero);
            $minutos = date("i", $fechaComoEntero);
            $fechaCompleta = $dia . "/" . $mes . "/" . $anio . " a las " . $hora . ":" . $minutos;
            $mail->Body = "Se ha realizado la reserva para la actividad de <b>" . $sesionReservada->title . "</b> en la sala " . $sesionReservada->sala . " el <b>" . $fechaCompleta."</b>.<br>Le esperamos!.";
            $mail->AltBody = "Le esperamos!";
            $mail->send();
        } catch (Exception $exception) {
            echo json_encode($exception);
        }
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
