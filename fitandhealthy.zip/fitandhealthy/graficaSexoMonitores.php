<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$object = (object) [
    'hombres' => '',
    'mujeres' => '',
];
try {
    $stmt = $conn->prepare("SELECT COUNT(*) as hombres FROM usuarios where sexo='hombre' and role=3");
    $stmt->execute();
    $filasObtenidas = $stmt->fetch();
    $stmt2 = $conn->prepare("SELECT COUNT(*) as mujeres FROM usuarios where sexo='mujer' and role=3");
    $stmt2->execute();
    $filasObtenidas2 = $stmt2->fetch();
    $object->mujeres=$filasObtenidas2->mujeres;
    $object->hombres=$filasObtenidas->hombres;

    echo json_encode($object);
} catch (PDOException $exception) {
    echo $exception;
}
