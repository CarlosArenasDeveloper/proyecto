<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
$email=$_GET['email'];
try {
        $html = "<html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <title>Alta</title>
            <link rel='stylesheet' href='estilos.css'>
        </head>
        <body>";
        $html .= "<h1>Alta</h1>";
        $html .= "<table>";
        $html .= "</table></body></html>";

        // require_once __DIR__ . '/vendor/autoload.php';
        require 'vendor/autoload.php';
        $mail = new PHPMailer(true);
        try {
            //  $mail->SMTPDebug=0;
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'fitandhealthycm@gmail.com';                     // SMTP username
            $mail->Password   = 'fitandhealthy';                               // SMTP password
            $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
            $mail->SMTPSecure = 'tls';        // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged

            //Recipients
            $mail->setFrom('fitandhealthycm@gmail.com', 'FIT & HEALTHY');
           // $mail->addAddress($params->email_cliente);     // Add a recipient 
           $mail->addAddress($email);     // Add a recipient 

            // Content
            $mail->isHTML(true);
            $mail->Subject = "Solicitud alta";
            $mail->Body = "Se ha solicitado el alta en Fit & Healthy.<small> Para completar: <a href='http://www.iestrassierra.net/alumnado/curso2021/DAW/daw2021a2/#/auth/solicitudAlta/$email'>pinche en el siguiente enlace.</small>";
            $mail->AltBody = "Le esperamos!";
            $mail->send();
        } catch (Exception $exception) {
            echo json_encode($exception);
        }
    
} catch (PDOException $exception) {
    echo json_encode($exception);
}
