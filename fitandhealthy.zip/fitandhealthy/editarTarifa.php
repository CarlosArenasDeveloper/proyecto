<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE tarifas set nombre=?
    ,descripcion=?,precio=?
    WHERE id=?");
    $stmt->bindParam(1, $params->nombre);
    $stmt->bindParam(2, $params->descripcion);
    $stmt->bindParam(3, $params->precio);
    $stmt->bindParam(4, $params->id);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
