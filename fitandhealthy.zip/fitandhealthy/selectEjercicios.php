<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
try {
    $stmt = $conn->prepare("SELECT * FROM ejercicios order by nombre_musculo ASC");
    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        foreach ($filasobtenidas as $fila) {
            if ($fila->nombre_musculo == null) {
                $fila->nombre_musculo = "sin asignar";
            } 
        }
    echo json_encode($filasobtenidas);

    } else {
        echo json_encode("error");
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
