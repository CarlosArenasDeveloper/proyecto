<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE centros set nombre=?
    ,direccion=?,telefono=?,latitud=?,longitud=?,ubicacion=?
    WHERE id=?");
    $stmt->bindParam(1, $params->nombre);
    $stmt->bindParam(2, $params->direccion);
    $stmt->bindParam(3, $params->telefono);
    $stmt->bindParam(4, $params->latitud);
    $stmt->bindParam(5, $params->longitud);
    $stmt->bindParam(6, $params->ubicacion);
    $stmt->bindParam(7, $params->id);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
