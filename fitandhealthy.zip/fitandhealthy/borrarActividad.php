<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("DELETE FROM actividades where id=:id");
    $stmt->bindParam(":id", $_GET["id"]);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
