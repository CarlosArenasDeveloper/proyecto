<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE ejercicios set nombre_musculo=?,nombre=?
    ,nivel=?,equipo=?,tipo=?,descripcion=?,imagen=?,video=? WHERE id=?");
    $stmt->bindParam(1,$params->nombre_musculo);
    $stmt->bindParam(2,$params->nombre);
    $stmt->bindParam(3,$params->nivel);
    $stmt->bindParam(4,$params->equipo);
    $stmt->bindParam(5,$params->tipo);
    $stmt->bindParam(6,$params->descripcion);
    $stmt->bindParam(7,$params->imagen);
    $stmt->bindParam(8,$params->video);
    $stmt->bindParam(9,$params->id);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
