<?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin:*");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();

// $json = file_get_contents('php://input');
// $params = json_decode($json);

// try {

//     $stm2 = $conn->prepare("UPDATE sesiones set estado='cancelada' WHERE id=:id");
//     $stm2->bindParam(":id", $_GET['id']);
//     $stm2->execute();

//     $stm = $conn->prepare("UPDATE reservas set estado='cancelada' WHERE id_sesion=:id_sesion");
//     $stm->bindParam(":id_sesion",$_GET['id']);
//     $stm->execute();
    
// } catch (PDOException $exception) {
//     echo json_encode($exception);
// }
