<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();


$jsondata;

try {
    $stmt = $conn->prepare("DELETE FROM usuarios where email=:email");
    $stmt2=$conn->prepare("UPDATE actividades set email_monitor=NULL where email_monitor=:email");
    $stmt2->bindParam(":email", $_GET["email"]);
    $stmt2->execute();
    $stmt->bindParam(":email", $_GET["email"]);
    $stmt->execute();
} catch (PDOException $exception) {
    echo $exception;
}
