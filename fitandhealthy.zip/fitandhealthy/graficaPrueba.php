<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$meses = [];
try {
    for ($i = 1; $i < 13; $i++) {
        $stmt = $conn->prepare("select T1.Cant As altas, T2.Cant As bajas FROM (SELECT COUNT(*) As Cant FROM usuarios where month(date(fecha_alta))=:alta and role=2 and year(date(fecha_alta))=:aniobis) As T1, (SELECT COUNT(*) As Cant FROM usuarios WHERE month(date(fecha_baja))=:baja and role=2 and year(date(fecha_baja))=:anio) As T2");
        $stmt->bindParam(":alta", $i);
        $stmt->bindParam(":aniobis", $_GET['anio']);
        $stmt->bindParam(":baja", $i);
        $stmt->bindParam(":anio", $_GET['anio']);
        $stmt->execute();
        $mes=$stmt->fetch();
        array_push($meses,$mes);
    }
} catch (PDOException $exception) {
    echo $exception;
}
echo json_encode($meses);

