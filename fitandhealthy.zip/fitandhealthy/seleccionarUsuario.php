<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("SELECT * FROM usuarios where email=:email");
    $stmt->bindParam(":email",$_GET["email"]);
    $stmt->execute();
    $filasobtenidas = $stmt->fetch();
    if($stmt->rowCount()>0){
        echo json_encode($filasobtenidas);
    }else{
        echo json_encode("error");
    }

    // $stmt2 = $conn->prepare("SELECT nombre  FROM centros where id=:id");
    // $stmt2->bindParam(":id",$filasobtenidas->id_centro);
    // $stmt2->execute();
    // $fila=$stmt2->fetch();

    
    // $stmt3 = $conn->prepare("SELECT nombre  FROM tarifas where id=:id");
    // $stmt3->bindParam(":id",$filasobtenidas->id_tarifa);
    // $stmt3->execute();
    // $fila3=$stmt3->fetch();

    // $filasobtenidas->id_centro=$fila->nombre;
    // $filasobtenidas->id_tarifa=$fila3->nombre;



    // if ($stmt->rowCount() > 0) {
    //     foreach($filasobtenidas as $fila){
    //         $jsondata[]= $fila;
    //     }
    // } else {
    //     echo json_encode("error");
    // }
} catch (PDOException $exception) {
    echo json_encode ($exception);
}
?>

