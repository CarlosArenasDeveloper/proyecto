<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE usuarios set fecha_alta=?,estado=?,fecha_baja=NULL
    WHERE email=?");
    $stmt->bindParam(1, $params->fecha_alta);
    $stmt->bindParam(2, $params->estado);
    $stmt->bindParam(3,$params->email);
    $stmt->execute();
    echo json_encode("correcto");
} catch (PDOException $exception) {
    json_encode($exception);
}
