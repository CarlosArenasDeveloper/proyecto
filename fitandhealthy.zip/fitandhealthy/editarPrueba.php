<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);

try {
    $stmt = $conn->prepare("SELECT COUNT(*) AS filas FROM sesiones WHERE (((:inicio BETWEEN start AND end) OR (:fin BETWEEN start AND end) OR (:inicio <=start and :fin >=end)) and title=:actividad) OR 
  (((:inicio BETWEEN start AND end) OR (:fin BETWEEN start AND end) OR (:inicio <=start and :fin >=end))  and sala=:sala)");
    $stmt->bindParam(":inicio", $params->start);
    $stmt->bindParam(":fin", $params->end);
    $stmt->bindParam(":sala", $params->sala);
    $stmt->bindParam(":actividad", $params->title);
    $stmt->execute();
    $filasobtenidas = $stmt->fetch();
    $filas=(int)$filasobtenidas->filas;
    if($filas >1){
        echo json_encode("error");
    }
    else {
        try {
            $stm2 = $conn->prepare("UPDATE sesiones set title=:title,start=:start
            ,end=:end,sala=:sala WHERE id=:id");
            $stm2->bindParam(":title", $params->title);
            $stm2->bindParam(":start", $params->start);
            $stm2->bindParam(":end", $params->end);
            $stm2->bindParam(":sala", $params->sala);
            $stm2->bindParam(":id", $params->id);
            $stm2->execute();
        } catch (PDOException $exception) {
            echo json_encode($exception);
        }
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
