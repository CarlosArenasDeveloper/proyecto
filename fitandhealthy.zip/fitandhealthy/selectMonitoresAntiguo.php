<?php
// header('Content-type: application/json; charset=utf-8');
// header("Access-Control-Allow-Origin: *");
// session_start();
// require_once 'conexion.php';
// $conn = openConection();


// $jsondata=[];

//     try {
//         $stmt = $conn->prepare("SELECT * FROM usuarios where role=3 order by apellido1");
//         $stmt->execute();
//         $filasobtenidas = $stmt->fetchAll();
//         if ($stmt->rowCount() > 0) {
//             foreach($filasobtenidas as $fila){
              
//                 $jsondata[]= $fila;
//             }
//         } else {
//             $jsondata[]="Error";
//         }
//     } catch (PDOException $exception) {
//         echo $exception;
//     }
// echo json_encode($jsondata);
