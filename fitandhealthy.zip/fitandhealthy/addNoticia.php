<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("INSERT INTO `noticias` (`id`, `email_usuario`, `titulo`, `cuerpo`, `id_categoria`, `visible`, `fecha`, `fecha_edit`, `imagen`) VALUES (NULL,?,?,?,?,?,?,NULL,?)");
    $stmt->bindParam(1, $params->email_usuario);
    $stmt->bindParam(2, $params->titulo);
    $stmt->bindParam(3, $params->cuerpo);
    $stmt->bindParam(4, $params->id_categoria);
    $stmt->bindParam(5, $params->visible);
    $stmt->bindParam(6, $params->fecha);
    $stmt->bindParam(7, $params->imagen);
    $stmt->execute();
} catch (PDOException $exception) {
    echo json_encode($exception);
}
