<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");
session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE salas set aforo=? WHERE id=?");
    $stmt->bindParam(1, $params->aforo);
    $stmt->bindParam(2, $params->id);
    $stmt->execute();
} catch (PDOException $exception) {
    json_encode($exception);
}
