<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin:*");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'conexion.php';
$conn = openConection();

$json = file_get_contents('php://input');
$params = json_decode($json);
try {
    $stmt = $conn->prepare("UPDATE usuarios set dni=?
    ,password=?,nombre=?,apellido1=?,
    apellido2=?,fecha_nac=?,sexo=?,telefono=?,cuenta_bancaria=?,ciudad=?,direccion=?
    ,cod_postal=?,id_tarifa=?,id_centro=?,fecha_alta=CURDATE(),fecha_baja=NULL,num_reservas=0,verificado=0,estado='activo' WHERE email=?");
    $stmt->bindParam(1, $params->dni);
    $stmt->bindParam(2, $params->password);
    $stmt->bindParam(3, $params->nombre);
    $stmt->bindParam(4, $params->apellido1);
    $stmt->bindParam(5, $params->apellido2);
    $stmt->bindParam(6, $params->fecha_nac);
    $stmt->bindParam(7, $params->sexo);
    $stmt->bindParam(8, $params->telefono);
    $stmt->bindParam(9, $params->cuenta_bancaria);
    $stmt->bindParam(10, $params->ciudad);
    $stmt->bindParam(11, $params->direccion);
    $stmt->bindParam(12, $params->cod_postal);
    $stmt->bindParam(13, $params->id_tarifa);
    $stmt->bindParam(14, $params->id_centro);
    $stmt->bindParam(15, $params->email);
    $stmt->execute();
    $stmt = $conn->prepare("SELECT *  FROM tarifas where id=:id");
    $stmt->bindParam(":id", $params->id_tarifa);
    $stmt->execute();
    $tarifa = $stmt->fetch();

    $html = "<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Email</title>
    <link rel='stylesheet' href='estilos.css'>
</head>
<body>";
    $html .= "<h1>Verificar email</h1>";
    $html .= "<table>";
    $html .= "</table></body></html>";

    // require_once __DIR__ . '/vendor/autoload.php';
    require 'vendor/autoload.php';
    $mail = new PHPMailer(true);
    try {
        //  $mail->SMTPDebug=0;
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'fitandhealthycm@gmail.com';                     // SMTP username
        $mail->Password   = 'fitandhealthy';                               // SMTP password
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        $mail->SMTPSecure = 'tls';        // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged

        //Recipients
        $mail->setFrom('fitandhealthycm@gmail.com', 'FIT & HEALTHY');
        $mail->addAddress($params->email);     // Add a recipient 

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Verificacion del email';
        //$mail->Body= "<small>Hola <b>". $params->nombre."</b>.<br> Gracias por contratar la tarifa <b>".$tarifa->nombre." por ".$tarifa->precio." euros</b>.<br>Para acceder a <b>FIT & HEALTHY</b> es necesario la verificacion de su correo electronico.<br>Haga click en el siguiente enlace para acceder con su email y password <a href='http://localhost/fitandhealthy/verificarEmail.php?email=$params->email'>fit&healthy.es</a></small>";
        $mail->Body = "<small>Bienvenido de nuevo <b>" . $params->nombre . "</b>.<br> Gracias por contratar la tarifa <b>" . $tarifa->nombre . " por " . $tarifa->precio . " euros</b>.<br>Para acceder a <b>FIT & HEALTHY</b> es necesario la verificacion de su correo electronico.<br>Haga click en el siguiente enlace para acceder con su email y password <a href='http://www.iestrassierra.net/alumnado/curso2021/DAW/daw2021a2/fitandhealthy/verificarEmail.php?email=$params->email'>fit&healthy.es</a></small>";

        // $mail->Body    = "<small>Confirmar email: <a href='http://localhost/fitandhealthy/verificarEmail.php?email=$params->email'>Pincha aqui para verificar</a></small>".$html;
        $mail->AltBody = 'Gracias por confiar en Fit & Healthy';
        $mail->send();
        echo json_encode("Email enviado");
    } catch (Exception $exception) {
        echo json_encode($exception);
    }
} catch (PDOException $exception) {
    json_encode($exception);
}
