<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("SELECT *  FROM sesiones where id=:id");
    $stmt->bindParam(":id",$_GET["id"]);
    $stmt->execute();
    $filasobtenidas = $stmt->fetch();
    if ($stmt->rowCount() > 0) {
        echo json_encode($filasobtenidas);
    } else {
        echo json_encode("error");
    }
} catch (PDOException $exception) {
    echo $exception;
}
?>

