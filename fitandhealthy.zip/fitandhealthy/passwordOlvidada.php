<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
require_once 'conexion.php';
$conn = openConection();

$json=file_get_contents('php://input');
$params=json_decode($json);
try {

    $html = "<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Email</title>
    <link rel='stylesheet' href='estilos.css'>
</head>
<body>";
$html .= "<table>";
$html .= "</table></body></html>";

    // require_once __DIR__ . '/vendor/autoload.php';
    require 'vendor/autoload.php';
    $mail= new PHPMailer(true);
    try{
        //$mail->SMTPDebug=0;
        $mail->isSMTP();                                            // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
        $mail->Username   = 'fitandhealthycm@gmail.com';                     // SMTP username
        $mail->Password   = 'fitandhealthy';                               // SMTP password
        $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        $mail->SMTPSecure = 'tls';        // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged

        //Recipients
        $mail->setFrom('fitandhealthycm@gmail.com', 'FIT & HEALTHY');
        $mail->addAddress($params->email);     // Add a recipient 

        // Content
        $mail->isHTML(true);                                  
        $mail->Subject = 'Reestablecer password';
        $mail->Body    ="<small>Hubo una solicitud para cambiar su password!<br>Si no realizo esta solicitud, ignore este correo electronico.<br> De lo contrario, <a href='http://www.iestrassierra.net/alumnado/curso2021/DAW/daw2021a2/#/auth/reestablecerPassword/$params->email'>haga clic en este enlace para cambiar su password</small>".$html;
        $mail->AltBody = 'Gracias por confiar en Fit & Healthy';
        $mail->send();
    }catch (Exception $exception){
    echo $exception;
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}

