<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();



try {
    $stmt = $conn->prepare("SELECT * FROM usuarios where email=:email");
    $stmt->bindParam(":email",$_GET["email"]);
    $stmt->execute();
    $filasobtenidas = $stmt->fetch();
    if($stmt->rowCount()>0){
        echo json_encode("existe");
    }else{
        echo json_encode("1");

    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
?>

