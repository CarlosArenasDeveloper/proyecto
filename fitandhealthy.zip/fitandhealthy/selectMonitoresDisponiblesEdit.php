<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();


$jsondata = [];

try {
    $stmt = $conn->prepare("SELECT * FROM usuarios where role=3 and email not in (SELECT `email_monitor` from `actividades`where email_monitor is not null) or email=:email");
    $stmt->bindParam(":email",$_GET['email']);
    $stmt2 = $conn->prepare("SELECT nombre  FROM centros where id=:id");

    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        foreach ($filasobtenidas as $fila) {
            if ($fila->id_centro != null) {
                $stmt2->bindParam(":id", $fila->id_centro);
                $stmt2->execute();
                $filaObt = $stmt2->fetch();
                $centro = $filaObt->nombre;
                $fila->id_centro = $centro;
            } else {
                $fila->id_centro = "sin asignar";
            }
            $jsondata[] = $fila;
        }
    } else {
        $jsondata[] = "Error";
    }
} catch (PDOException $exception) {
    echo $exception;
}
echo json_encode($jsondata);
