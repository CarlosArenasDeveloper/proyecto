<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
$datos = [];
$jsondata = [];
$object = (object) [
    'realizadas' => '',
    'canceladas' => '',
    'pendientes' => '',
];
try {
    $stmt = $conn->prepare("select (select count(*) as numero from reservas where email_cliente=:email and estado='realizada'), (select count(*) as numero2 from reservas where email_cliente=:email and estado='pendiente'), count(*) as numero3 from reservas where email_cliente=:email and estado='cancelada'");
    $stmt->bindParam(":email",$_GET['email']);
    $stmt->execute();
    $filasObtenidas = $stmt->fetch(PDO::FETCH_NUM);    
    $object->realizadas=$filasObtenidas[0];
    $object->canceladas=$filasObtenidas[2];
    $object->pendientes=$filasObtenidas[1];

    echo json_encode($object);

    

  
} catch (PDOException $exception) {
    echo json_encode($exception);
}

