<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();
try {
    $stmt = $conn->prepare("SELECT * FROM sesiones order by id");
    $stmt2 = $conn->prepare("SELECT nombre  FROM actividades where id=:id");

    $stmt->execute();
    $filasobtenidas = $stmt->fetchAll();
    if ($stmt->rowCount() > 0) {
        foreach ($filasobtenidas as $fila) {
            if ($fila->id_actividad != null) {
                $stmt2->bindParam(":id", $fila->id_actividad);
                $stmt2->execute();
                $filaObt = $stmt2->fetch();
                $actividad = $filaObt->nombre;
                $fila->id_actividad = $actividad;
            } else {
                $fila->id_actividad = "sin asignar";
            }

            if ($fila->id_sala == null) {
                $fila->id_sala = "sin asignar";
            }
        }
        echo json_encode($filasobtenidas);
    } else {
        echo json_encode("error");
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
