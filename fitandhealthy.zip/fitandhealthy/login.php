<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'conexion.php';
$conn = openConection();
$email = $_GET["email"];
try {
    $stmt = $conn->prepare("SELECT * FROM usuarios where email=:email and password=:password");
    $stmt->bindParam(":email", $_GET["email"]);
    $stmt->bindParam(":password", $_GET["password"]);
    $stmt->execute();
    $filasobtenidas = $stmt->fetch();
    if ($stmt->rowCount() > 0) {
        echo json_encode($filasobtenidas);    
    } else {
        echo json_encode(("error"));
    }
} catch (PDOException $exception) {
    echo json_encode($exception);
}
