<?php
header('Content-type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
session_start();
require_once 'conexion.php';
$conn = openConection();

try {
    $stmt = $conn->prepare("UPDATE usuarios set verificado=1
    WHERE email=?");
    $stmt->bindParam(1,$_GET['email']);
    $stmt->execute();
    header("location: http://www.iestrassierra.net/alumnado/curso2021/DAW/daw2021a2/#/auth/login");
} catch (PDOException $exception) {
    json_encode($exception);
}